namespace MathFuncs
{
	class MyMath
	{
	public:
		static double add(double a, double b);
		static double substract(double a, double b);
		static double multiply(double a, double b);
		static double divide(double a, double b);
		static double log(double a, double b);
		static double pow(double a, double b);

	};
}